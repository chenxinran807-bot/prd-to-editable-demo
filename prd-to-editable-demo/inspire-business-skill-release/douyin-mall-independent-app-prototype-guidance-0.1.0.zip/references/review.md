# Review Gate

Before completion, inspect the generated prototype and record failures instead of silently fixing the requirements:

- No Emoji, text glyph icons, invented logos or unapproved external assets.
- No generic purple gradient, desktop navigation, dashboard shell or fake phone frame.
- Every required PRD action is reachable and every required state is represented.
- Touch actions have readable business labels and do not rely on color alone.
- No invented price, promotion, entitlement, inventory or brand promise.
- The selected skill appears as opened in the Inspire diagnostics trace.

Deterministic checks do not establish visual quality. The owner must open the preview and judge hierarchy, native-mobile character, material quality and business meaning.

